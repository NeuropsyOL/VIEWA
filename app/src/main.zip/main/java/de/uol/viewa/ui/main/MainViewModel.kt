package de.uol.viewa.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import de.uol.viewa.LSLService
import de.uol.viewa.ui.main.utils.ColorPalette
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

// A simple UI state holding the latest list of chart Entries
// and the all time max/min values used for axis scaling
//
data class ChartUiState(
    val entries: List<ILineDataSet> = emptyList(),
    val yMin: Float = Float.POSITIVE_INFINITY,
    val yMax: Float = Float.NEGATIVE_INFINITY
)


class MainViewModel : ViewModel() {


    private var pausePlotting = false
    private var allTimeMin = Float.POSITIVE_INFINITY
    private var allTimeMax = Float.NEGATIVE_INFINITY

    private val maxPoints = 60  // keep last 60 samples
    private val _uiState =
        MutableStateFlow<ChartUiState>(ChartUiState(emptyList<ILineDataSet>(), -1f, 1f))
    val uiState: StateFlow<ChartUiState> = _uiState.asStateFlow()

    fun togglePause() {
        pausePlotting = !pausePlotting
    }

    /**
     * Begin collecting from the service events flow.
     * Filters for DataSample events matching `streamName`,
     * converts each FloatArray into an MPAndroidChart Entry list,
     * and updates _uiState.
     */
    fun startCollecting(events: SharedFlow<LSLService.ServiceEvent>) {
        viewModelScope.launch {
            val config = events.filterIsInstance<LSLService.ServiceEvent.StreamConfig>().first()
            val buffers =
                (0 until config.channelCount).associateWith { ArrayDeque<Entry>(maxPoints) }
            events
                .filterIsInstance<LSLService.ServiceEvent.DataSample>()
                .filter { true }
                .collect { dataSample ->
                    val t = dataSample.timestamp.toFloat()
                    val ys = dataSample.sample
                    // 2 add each channel’s new Entry
                    buffers.forEach { (i, buf) ->
                        if (buf.size == maxPoints) buf.removeFirst()
                        buf.addLast(Entry(t, ys[i]))
                        buf.filter { t -> buf.last().x - t.y < 5 }
                    }
                    // 3 build LineDataSets
                    val cp = ColorPalette()
                    val sets: List<ILineDataSet> = buffers.map { (i, buf) ->
                        LineDataSet(buf.toList(), "Ch $i").apply {
                            setDrawCircles(false)
                            lineWidth = 1f
                            color += cp.nextColor()
                        }
                    }

                    // after you update all your buffers…
                    val allValues = buffers.flatMap { it.value.toList() }.map { it.y }
                    val currentMin = allValues.minOrNull() ?: 0f
                    val currentMax = allValues.maxOrNull() ?: 0f

                    allTimeMin = min(allTimeMin, currentMin)
                    allTimeMax = max(allTimeMax, currentMax)

                    if (!pausePlotting)
                        _uiState.value = ChartUiState(sets, allTimeMin, allTimeMax)
                }
        }
    }

    fun resetRange() {
        // reset to some sensible defaults, e.g. ±1
        val defaultMin = Float.POSITIVE_INFINITY
        val defaultMax = Float.NEGATIVE_INFINITY
        _uiState.value = _uiState.value.copy(yMin = defaultMin, yMax = defaultMax)
    }
}