package de.uol.viewa

import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import edu.ucsd.sccn.LSL
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlin.random.Random

class LSLService : LifecycleService() {

    sealed class ServiceEvent {
        data class DataSample(val streamName: String,val timestamp:Double, val sample: FloatArray) : ServiceEvent()
        data class StreamConfig(val streamName:String,val channelCount:Int) : ServiceEvent()

    }

    private val _events = MutableSharedFlow<ServiceEvent>(extraBufferCapacity = 100, replay=1)
    val events: SharedFlow<ServiceEvent> = _events
    private lateinit var inlet:LSL.StreamInlet

    private val localBinder = LocalBinder()

    override fun onBind(intent: Intent): IBinder {
        super.onBind(intent)    // important for LifecycleService
        return localBinder      // return your binder here
    }

    override fun onCreate() {
        super.onCreate()
        startInlet()
    }

    fun startInlet(){
        var availableStreams=LSL.resolve_streams()
        if(availableStreams.isNotEmpty()) {
            var myStreamInfo = availableStreams[0]
            _events.tryEmit(ServiceEvent.StreamConfig(myStreamInfo.name(),myStreamInfo.channel_count()))
            inlet = LSL.StreamInlet(myStreamInfo)
            lifecycleScope.launch(Dispatchers.IO) {
                val buffer = FloatArray(myStreamInfo.channel_count())
                while (isActive) {
                    val timestamp = inlet.pull_sample(buffer)   // blocking until data arrives
                    _events.emit(ServiceEvent.DataSample(inlet.info().name(),timestamp,buffer.copyOf()))
                }
            }
        }
        else
        {
            Log.e("LSLService","Could not find any streams!")
            Toast.makeText(applicationContext,"Could not find any streams!",Toast.LENGTH_LONG)
        }
    }

    // Binder to return the Flow:
    inner class LocalBinder : Binder() {
        fun service(): LSLService = this@LSLService
    }
}