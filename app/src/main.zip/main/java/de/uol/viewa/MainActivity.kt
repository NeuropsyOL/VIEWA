package de.uol.viewa

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.LineData
import de.uol.neuropsy.viewa.R
import de.uol.viewa.ui.chart.ChartGestureHandler
import de.uol.viewa.ui.main.MainViewModel


class MainActivity : AppCompatActivity() {

    private val viewModel: MainViewModel by viewModels()
    private var service: LSLService? = null

    private var plottingLastRefresh = System.currentTimeMillis()
    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val localBinder = binder as LSLService.LocalBinder
            service = localBinder.service()
            // Tell the VM to start collecting the "EEG" stream
            Log.i("MainActivity", "telling viewModel to startCollecting...")
            viewModel.startCollecting(service!!.events)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
        }
    }

    override fun onStart() {
        super.onStart()
        Intent(this, LSLService::class.java).also { intent ->
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        unbindService(connection)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val chart: LineChart = findViewById(R.id.lineChart)
        chart.axisRight.isEnabled = false
        chart.description.isEnabled = false
        chart.setMaxVisibleValueCount(0)

        chart.onChartGestureListener = ChartGestureHandler(
            onTogglePause  = { viewModel.togglePause() },
            onReset = {viewModel.resetRange()}
        )

        lifecycleScope.launchWhenStarted {
            viewModel.uiState.collect { state ->
                val pkgArrivalTime = System.currentTimeMillis()
                val plottingElapsed: Long = pkgArrivalTime - plottingLastRefresh
                val plottingFPS = 25
                if (plottingElapsed > 1000 / plottingFPS) {
                    chart.data = LineData(state.entries)
                    chart.axisLeft.axisMinimum = state.yMin
                    chart.axisLeft.axisMaximum = state.yMax
                    chart.invalidate()
                    plottingLastRefresh = System.currentTimeMillis()
                }
            }
        }
    }
}