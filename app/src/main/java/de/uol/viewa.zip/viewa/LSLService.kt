package de.uol.viewa

import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import edu.ucsd.sccn.LSL
import edu.ucsd.sccn.LSL.StreamInlet
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlin.random.Random

class LSLService : LifecycleService() {

    sealed class ServiceEvent {
        data class DataSample(val streamName: String,val timestamp:Double, val sample: FloatArray) : ServiceEvent()
        data class StreamConfig(val streamName:String,val channelCount:Int) : ServiceEvent()

    }

    private val _events = MutableSharedFlow<ServiceEvent>(extraBufferCapacity = 100, replay=1)
    val events: SharedFlow<ServiceEvent> = _events

    private val inletJobs = mutableMapOf<String, Job>()

    private val localBinder = LocalBinder()

    override fun onBind(intent: Intent): IBinder {
        super.onBind(intent)    // important for LifecycleService
        return localBinder      // return your binder here
    }

    override fun onCreate() {
        super.onCreate()
    }

    fun startInlet(streamName : String){
        if (inletJobs.containsKey(streamName)) return
        val info = LSL.resolve_stream("name", streamName).firstOrNull() ?: return
        val inlet = LSL.StreamInlet(info)
        val job = lifecycleScope.launch(Dispatchers.IO) {
            val buf = FloatArray(info.channel_count())
            while (isActive) {
                val timestamp = inlet.pull_sample(buf, LSL.FOREVER)
                _events.emit(ServiceEvent.DataSample(streamName, timestamp, buf.copyOf()))
            }
        }
        inletJobs[streamName] = job
    }

    fun stopInlet(streamName: String) {
        inletJobs.remove(streamName)?.also { job->job.cancel() }
    }

    fun stopAll(){
        //inletJobs.forEach {stopInlet(it.key)
        //    Log.e("LSLService",it.key)}
    }

    // Binder to return the Flow:
    inner class LocalBinder : Binder() {
        fun service(): LSLService = this@LSLService
    }
}