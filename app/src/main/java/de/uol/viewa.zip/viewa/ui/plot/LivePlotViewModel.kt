package de.uol.viewa.ui.plot

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import de.uol.viewa.LSLService
import de.uol.viewa.ui.main.utils.ColorPalette
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.forEach
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

// A simple UI state holding the latest list of chart Entries
// and the all time max/min values used for axis scaling
//
data class ChartUiState(
    val entries: List<ILineDataSet> = emptyList(),
    val yMin: Float = Float.POSITIVE_INFINITY,
    val yMax: Float = Float.NEGATIVE_INFINITY
)

class LivePlotViewModel : ViewModel() {

    private val maxPoints=60
    private var pausePlotting = false
    private var allTimeMin = mutableMapOf<String,Float>()
    private var allTimeMax = mutableMapOf<String,Float>()
    private var collectJob: Job? = null
    private val buffers = mutableMapOf<String,Map<Int,ArrayDeque<Entry>>>()
    private val _uiState =
        MutableStateFlow<Map<String,ChartUiState>>(emptyMap())
    val uiState: StateFlow<Map<String,ChartUiState>> = _uiState.asStateFlow()

    fun togglePause() {
        pausePlotting = !pausePlotting
    }

    // Track currently active streams
    //private val activeStreams = mutableSetOf<String>()

    /**
     * Begin collecting from the service events flow.
     * Filters for DataSample events matching `streamName`,
     * converts each FloatArray into an MPAndroidChart Entry list,
     * and updates _uiState.
     */
    fun startCollecting(streams : List<String>, events: SharedFlow<LSLService.ServiceEvent>) {
        Log.e("LivPlotViewModel","startCollecting")
        // Cancel any previous collection
        collectJob?.cancel()
        buffers.clear()
        allTimeMin.clear()
        allTimeMax.clear()

        collectJob=viewModelScope.launch {
            events.filterIsInstance<LSLService.ServiceEvent.StreamConfig>().collect { config ->
                if (config.streamName in streams) {
                    (0 until config.channelCount)
                        .associateWith { ArrayDeque<Entry>(maxPoints) }
                    allTimeMin[config.streamName] = Float.POSITIVE_INFINITY
                    allTimeMax[config.streamName] = Float.NEGATIVE_INFINITY
                }
            }

            events.filterIsInstance<LSLService.ServiceEvent.DataSample>().collect {
                Log.e(
                    "LivePlotViewModel",
                    "Got new sample for ${it.streamName}: ${it.streamName} ${it.sample.contentToString()}"
                )
            }
            /*
                .filterIsInstance<LSLService.ServiceEvent.DataSample>()
                .filter { it.streamName in streams }
                .collect { sampleEv ->
                    val name = sampleEv.streamName
                    val t    = sampleEv.timestamp.toFloat()
                    val ys   = sampleEv.sample
                    val chBufs = buffers[name]!!       // your channel→deque map



                    // 2 add each channel’s new Entry
                    chBufs.forEach { (i, buf) ->
                        if (buf.size == maxPoints) buf.removeFirst()
                        buf.addLast(Entry(t, ys[i]))
                        buf.filter { t -> buf.last().x - t.y < 5 }
                    }

                    // Compute this stream's current min/max
                    val allValues = chBufs.flatMap { it.value.toList() }.map { it.y }
                    val currentMin = allValues.minOrNull() ?: 0f
                    val currentMax = allValues.maxOrNull() ?: 0f

                    allTimeMin[name] = min(allTimeMin[name]!!, currentMin)
                    allTimeMax[name] = max(allTimeMax[name]!!, currentMax)


                    val cp = ColorPalette()
                    // 7) Build a ChartUiState for each stream
                    if (!pausePlotting) {
                        val stateMap = buffers.mapValues { (stream, bufMap) ->
                            // create one DataSet per channel
                            val sets = bufMap.map { (i, buf) ->
                                LineDataSet(buf.toList(), "$stream Ch-$i").apply {
                                    setDrawCircles(false)
                                    lineWidth = 1f
                                    color = cp.nextColor()
                                }
                            }
                            ChartUiState(
                                entries = sets,
                                yMin      = allTimeMin[stream]!!,
                                yMax      = allTimeMax[stream]!!
                            )
                        }
                        _uiState.value = stateMap
                        Log.e("LivePlotViewModel","Got new sample for $name: $t ${ys.contentToString()}")
                    }
                    */
        }
    }

    fun stopCollecting(){
        _uiState.value = emptyMap()
    }

    fun resetRange() {
        // reset to some sensible defaults, e.g. ±1
        val defaultMin = Float.POSITIVE_INFINITY
        val defaultMax = Float.NEGATIVE_INFINITY
        //_uiState.value = _uiState.value.copy(yMin = defaultMin, yMax = defaultMax)
    }
}